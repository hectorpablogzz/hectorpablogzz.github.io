package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class PersonProfileController implements Initializable {
	
	@FXML private Button backButton;
	@FXML private Button infoButton;
	@FXML private Button prefsButton;
	@FXML private Button deleteButton;
	
	@FXML private Label nameLabel;
	@FXML private Label errorLabel;
	
	boolean confirm = false;
	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		nameLabel.setText(PersonListController.selectedLawyer.getName());
		
	}
	
	@FXML public void backPressed(ActionEvent event) {
		if (PersonListController.selectedLawyer.getName().equals("Nueva Persona")) {
			errorLabel.setText("Favor de llenar información primero.");
		} else {
			Stage stage = (Stage) backButton.getScene().getWindow();
			
			stage.close();
		}
		
	}
	
	@FXML public void infoPressed(ActionEvent event) {
		Parent rootInfo = null;
		try {
			rootInfo = FXMLLoader.load(getClass().getResource("/application/InfoGUI.fxml"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		PersonListController.selectedLawyer.setPrefs("PODER LEGISLATIVO");
		Scene sceneInfo = new Scene(rootInfo);
		PersonListController.personProfile.setScene(sceneInfo);
		PersonListController.personProfile.show();
	}
	
	@FXML public void prefsPressed (ActionEvent event) {
		if (PersonListController.selectedLawyer.getName().equals("Nueva Persona")) {
			errorLabel.setText("Favor de llenar información primero.");
		} else {
			
			System.out.println(PersonListController.selectedLawyer.getPrefs());
			Parent rootPrefs = null;
			try {
				rootPrefs = FXMLLoader.load(getClass().getResource("/application/PrefsGUI.fxml"));
			} catch (IOException e) {
				e.printStackTrace();
			}
			Scene scenePrefs = new Scene(rootPrefs);
			PersonListController.personProfile.setScene(scenePrefs);
			PersonListController.personProfile.show();
		}
		
		
		
	}
	
	@FXML public void deletePressed (ActionEvent event) {
		
		if (PersonListController.selectedLawyer.getName().equals("Nueva Persona")) {
			Stage stage = (Stage) backButton.getScene().getWindow();
			
			stage.close();
		} else if (confirm) {
			boolean exists = false;
			for (int i = 0; i < LoginController.lawyers.size() && exists == false; i++) {
				if (PersonListController.selectedLawyer.equals(LoginController.lawyers.get(i))) {
					LoginController.lawyers.remove(i);
				}
			}
			Stage stage = (Stage) backButton.getScene().getWindow();
			
			stage.close();
			
		}
		else {
			errorLabel.setText("¿Seguro/a? Vuelva a hacer click para confirmar.");
			confirm = true;
		}
	}

}
