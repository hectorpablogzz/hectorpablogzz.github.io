package controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLTools {
	
	public static void main(String[] args) throws IOException {
		downloadXML();
		XMLToArticle();

	}
	
	public static void downloadXML() throws UnknownHostException {
		try {
			URL url = new URL("http://www.diariooficial.gob.mx/sumario.xml");
			ReadableByteChannel rbc = Channels.newChannel(url.openStream());
			FileOutputStream fos = new FileOutputStream("Files/sumario.xml");
			fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
			fos.close();
			rbc.close();
			
			System.out.println();
			System.out.println("**************************");
			System.out.println("file downloaded successfully.");
			System.out.println("**************************");
			System.out.println();
			
		} catch (Exception e) {
			System.out.println("Error, could not download file. Check your internet connection or try again.");
			e.printStackTrace();
			System.exit(0);
		}
	}
	
	public static ArrayList<Article> XMLToArticle() {
		ArrayList<Article> articles = new ArrayList<Article>();
		
		String[] titles = new String[0];
		String[] links = new String[0];
		String[] descriptions = new String[0];
		String[] dates = new String[0];
		
		try {
			File xmlFile = new File("Files/sumario.xml");
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
			
			//Extract titles
			
			NodeList nList = doc.getElementsByTagName("title");
			titles = new String[nList.getLength()];
			
			for (int i = 0; i < nList.getLength(); i++) {
                Node nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    titles[i] = eElement.getTextContent();
                }
            }
			
			for (String s : titles) {
                System.out.println(s);
            }
			
			//Extract links
			
			nList = doc.getElementsByTagName("link");
			links = new String[nList.getLength()];
			
			for (int i = 0; i < nList.getLength(); i++) {
                Node nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    links[i] = eElement.getTextContent();
                }
            }
			
			for (String s : links) {
                System.out.println(s);
            }
			
//Extract descs.
			
			nList = doc.getElementsByTagName("description");
			descriptions = new String[nList.getLength()];
			
			for (int i = 0; i < nList.getLength(); i++) {
                Node nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    descriptions[i] = eElement.getTextContent();
                }
            }
			
			for (String s : descriptions) {
                System.out.println(s);
            }
			
//Extract dates
			
			nList = doc.getElementsByTagName("valueDate");
			dates = new String[nList.getLength()];
			
			for (int i = 0; i < nList.getLength(); i++) {
                Node nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    dates[i] = eElement.getTextContent();
                }
            }
			
			for (String s : dates) {
                System.out.println(s);
            }
			System.out.println();
			System.out.println("**************************");
			System.out.println("Info loaded to memory");
			System.out.println("**************************");
			System.out.println();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Save info to articles
		
		int count = 2;
		
		while (count < titles.length) {
			Article article = new Article();
			
			article.setTitle(titles[count]);
			article.setLink(links[count]);
			
			String oldchars = "&aacute;";
			String newchars = "á";
			
			descriptions[count-1] = descriptions[count-1].replaceAll(oldchars, newchars);

			oldchars = "&eacute;";
			newchars = "é";
			
			descriptions[count-1] = descriptions[count-1].replaceAll(oldchars, newchars);
			
			oldchars = "&iacute;";
			newchars = "í";
			
			descriptions[count-1] = descriptions[count-1].replaceAll(oldchars, newchars);
			
			oldchars = "&oacute;";
			newchars = "ó";
			
			descriptions[count-1] = descriptions[count-1].replaceAll(oldchars, newchars);
			
			oldchars = "&uacute;";
			newchars = "ú";
			
			descriptions[count-1] = descriptions[count-1].replaceAll(oldchars, newchars);
			
			oldchars = "&ntilde;";
			newchars = "ñ";
			
			descriptions[count-1] = descriptions[count-1].replaceAll(oldchars, newchars);
			
			
			
			
			article.setDescription(descriptions[count-1]);
			article.setDate(dates[count-2]);
			
			System.out.println(article.getTitle());
			System.out.println(article.getDescription());
			System.out.println(article.getLink());
			System.out.println(article.getDate());
			
			articles.add(article);
			count++;
		}
		
		System.out.println("**************************");
		System.out.println("Finished sorting articles");
		System.out.println("**************************");
		
		//Snippet of code that writes all articles to output.txt, for testing purposes.
		/*
		try {
			File dir = new File("Files");
			dir.mkdirs();
			String txtFile = "Files/output.txt";
			BufferedReader br = null;
			FileWriter writer;
			br = new BufferedReader(new FileReader(txtFile));
			
			writer = new FileWriter(txtFile, false);
			for (int k = 0; k < articles.size(); k++) {
					
					System.out.println(articles.get(k).getTitle());
					writer.append(articles.get(k).getTitle() + "\n");
					writer.append(articles.get(k).getDate() + "\n");
					writer.append(articles.get(k).getDescription() + "\n");
					writer.append(articles.get(k).getLink() + "\n");
					writer.append("\n");
				
			}
			writer.flush();
			writer.close();
			br.close();
		} catch (Exception e) {
			
		}
		
		*/
		return articles;
	}
	

}
