package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class PrefsController implements Initializable {
	
	@FXML private TableView<Categories> prefsTable;
	@FXML private TableColumn<Categories, String> categoryCol;
	@FXML private TableColumn<Categories, String> statusCol;
	
	@FXML private Button enableButton;
	@FXML private Button disableButton;
	@FXML private Button saveButton;
	
	public ArrayList<Categories> categories = new ArrayList<Categories>();
	
	@FXML private ObservableList<Categories> data = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		updateTable();
		
		String[] categoriesList = {"PODER LEGISLATIVO", "PODER EJECUTIVO", "PODER JUDICIAL", "ORGANISMOS AUTONOMOS", "EMPRESAS PRODUCTIVAS DEL ESTADO", "ORGANISMOS DESCONCENTRADOS O DESCENTRALIZADOS", "CONVOCATORIAS PARA CONCURSOS DE ADQUISICIONES", "ARRENDAMIENTOS, OBRAS Y SERVICIOS DEL SECTOR PUBLICO", "CONVOCATORIAS PARA CONCURSOS DE PLAZAS VACANTES DEL SERVICIO", "PROFESIONAL DE CARRERA EN LA ADMINISTRACION PUBLICA FEDERAL", "AVISOS JUDICIALES Y GENERALES"};
		
		
		String prefs = PersonListController.selectedLawyer.getPrefs();
		System.out.println(prefs);
		String enabledCategories[] =  prefs.trim().split(":");
		
		
		
		for (int i = 0; i < categoriesList.length; i++) {
			Categories category = new Categories();
			category.setCategory(categoriesList[i]);
			category.setEnabled("X");
			if (enabledCategories.length != 0) {
				for (int j = 0; j < enabledCategories.length; j++) {
					if (category.getCategory().equals(enabledCategories[j] )) {
						category.setEnabled("√");
					}
				}
			}
			
			categories.add(category);
			System.out.println(category.getCategory());
			System.out.println(category.getEnabled());
		}
		
		updateTable();
		
	}
	
	public void enablePressed (ActionEvent event) {
		Categories selectedCategory = prefsTable.getSelectionModel().getSelectedItem();

		for (int i = 0; i < categories.size(); i++) {
			if (selectedCategory.equals(categories.get(i))) {
				categories.get(i).setEnabled("√");
			}
		}
		updateTable();
	}
	
	public void disablePressed (ActionEvent event) {
		Categories selectedCategory = prefsTable.getSelectionModel().getSelectedItem();

		for (int i = 0; i < categories.size(); i++) {
			if (selectedCategory.equals(categories.get(i))) {
				categories.get(i).setEnabled("X");
			}
		}
		updateTable();
	}
	
	public void savePressed (ActionEvent event) {
		String newPrefs = "";
		for (int i = 0; i < categories.size(); i++) {
			if (categories.get(i).getEnabled().equals("√")) {
				newPrefs = newPrefs + categories.get(i).getCategory() + ":";
			}
			
		}
		for (int i = 0; i < LoginController.lawyers.size(); i++) {
			if (PersonListController.selectedLawyer.equals(LoginController.lawyers.get(i))) {
				LoginController.lawyers.get(i).setPrefs(newPrefs);
				System.out.println(newPrefs);
			}
		}
		
		Parent rootPersonProfile = null;
		try {
			rootPersonProfile = FXMLLoader.load(getClass().getResource("/application/PersonProfileGUI.fxml"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		Scene scenePersonProfile = new Scene(rootPersonProfile);
		PersonListController.personProfile.setScene(scenePersonProfile);
		PersonListController.personProfile.show();
	
	}
	
	public void updateTable() {
		
		prefsTable.getItems().clear();
		
		categoryCol.setCellValueFactory(new PropertyValueFactory<Categories, String>("category"));
		statusCol.setCellValueFactory(new PropertyValueFactory<Categories, String>("enabled"));
		
		for (int i = 0; i < categories.size(); i++) {
			data.add(categories.get(i));
		}
		prefsTable.setItems(data);
	}

}
