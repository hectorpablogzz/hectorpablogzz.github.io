package controllers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class PersonListController implements Initializable {
	
	@FXML private Button backButton;
	@FXML private Button editButton;
	@FXML private Button addButton;
	@FXML private Button updateButton;
	
	@FXML private TableView<Lawyer> lawyerTable;
	@FXML private TableColumn<Lawyer, String> nameCol;
	@FXML private TableColumn<Lawyer, String> lastNameCol;
	@FXML private TableColumn<Lawyer, String> firmCol;
	
	@FXML private ObservableList<Lawyer> data = FXCollections.observableArrayList();
	
	
	public static Stage personProfile = new Stage();
	
	public static Lawyer selectedLawyer = new Lawyer();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		updateTable();
	}
	
	@FXML
	public void backPressed (ActionEvent event) {
		memoryToCSV();
		Stage stage = (Stage) backButton.getScene().getWindow();
		stage.close();
	}
	
	@FXML
	public void editPressed (ActionEvent event) throws IOException {
		selectedLawyer = lawyerTable.getSelectionModel().getSelectedItem();
		Parent rootPersonProfile = FXMLLoader.load(getClass().getResource("/application/PersonProfileGUI.fxml"));
		Scene scenePersonProfile = new Scene(rootPersonProfile);
		personProfile.setScene(scenePersonProfile);
		personProfile.show();
	}
	
	public void addPressed (ActionEvent event) throws IOException {
		selectedLawyer = new Lawyer();
		selectedLawyer.setName("Nueva Persona");
		selectedLawyer.setPrefs("PODER LEGISLATIVO");
		
		Parent rootAddPerson = FXMLLoader.load(getClass().getResource("/application/PersonProfileGUI.fxml"));
		Scene sceneAddPerson = new Scene(rootAddPerson);
		personProfile.setScene(sceneAddPerson);
		personProfile.show();
	}
	
	public void updatePressed (ActionEvent event) throws IOException {
		updateTable();
	}
	
	public void updateTable() {
		lawyerTable.getItems().clear();
		
		nameCol.setCellValueFactory(new PropertyValueFactory<Lawyer, String>("name"));
		lastNameCol.setCellValueFactory(new PropertyValueFactory<Lawyer, String>("lastName"));
		firmCol.setCellValueFactory(new PropertyValueFactory<Lawyer, String>("firm"));
		
		for (int i = 0; i < LoginController.lawyers.size(); i++) {
			data.add(LoginController.lawyers.get(i));
		}
		lawyerTable.setItems(data);
		
	}
	
	public void memoryToCSV() {
		try {
			File dir = new File("Files");
			dir.mkdirs();
			String csvFile = "Files/lawyers.csv";
			BufferedReader br = null;
			FileWriter writer;
			writer = new FileWriter(csvFile, false);
			
			br = new BufferedReader(new FileReader(csvFile));
			
			
			for (int i = 0; i < LoginController.lawyers.size(); i++) {
				writer.append(LoginController.lawyers.get(i).getName() + ",");
				writer.append(LoginController.lawyers.get(i).getLastName() + ",");
				writer.append(LoginController.lawyers.get(i).getFirm() + ",");
				writer.append(LoginController.lawyers.get(i).getMail() + ",");
				writer.append(LoginController.lawyers.get(i).getPrefs() + "\n");
			}
			writer.flush();
			writer.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
