package controllers;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController implements Initializable {
	
	@FXML private Button loginButton;
	@FXML private Button quitButton;
	@FXML private TextField userField;
	@FXML private PasswordField passField;
	@FXML private Label errorLabel;
	
	public static ArrayList<Lawyer> lawyers = new ArrayList<Lawyer>();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
		
		try {
			Scanner lawyerScan = new Scanner(new File("Files/lawyers.csv"));
			while (lawyerScan.hasNext()) {
				Lawyer lawyer = new Lawyer();
				String[] values = lawyerScan.nextLine().split(",");
				lawyer.setName(values[0]);
				lawyer.setLastName(values[1]);
				lawyer.setFirm(values[2]);
				lawyer.setMail(values[3]);
				lawyer.setPrefs(values[4]);
				lawyers.add(lawyer);
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	
	}
	
	@FXML
	public void loginPressed (ActionEvent event) {
		
		ArrayList<String> users = new ArrayList<String>();
		ArrayList<String> passwords = new ArrayList<String>();
		
		
		
		try {
			Scanner csvScan = new Scanner(new File("Files/users.csv"));
			

			
			while (csvScan.hasNext()){  
				String[] values = csvScan.nextLine().split(",");
				users.add(values[0]);
				passwords.add(values[1]);
			}   
			csvScan.close();
			
		} catch (FileNotFoundException e) {
			errorLabel.setText("No se encontraron los usuarios, favor de contactar a soporte técnico.");
			e.printStackTrace();
		}
		
		String user = userField.getText();
		String pass = passField.getText();
		
		
		boolean loop = true;
		boolean correct = false;
		
		int count = 0;
		
		while (loop && count < users.size()) {
			String correctUser = users.get(count);
			String correctPass = passwords.get(count);
			
			if (user.equals(correctUser) && pass.equals(correctPass)) {
				loop = false;
				correct = true;
			}
			count++;
		}
		
		if (correct) {
			application.Main.mainStage = (Stage) loginButton.getScene().getWindow();
			application.Main.mainStage.setScene(application.Main.scene2);
		}
		
		else {
			errorLabel.setText("Usuario o contraseña incorrectos, vuelva a intentar.");
		} 
		
		
	}
	
	@FXML
	public void quitPressed (ActionEvent event) {
		System.exit(0);
	}

}
