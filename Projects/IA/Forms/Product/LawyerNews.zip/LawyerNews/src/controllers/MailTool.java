package controllers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class MailTool {
	
	
	
	public static void exportToTXT() {
		boolean mailToday = false;
		try {
			File dir = new File("Files");
			dir.mkdirs();
			String txtFile = "Files/output.txt";
			BufferedReader br = null;
			FileWriter writer;
			writer = new FileWriter(txtFile, false);
			br = new BufferedReader(new FileReader(txtFile));
			
			
			
			for (int i = 0; i < LoginController.lawyers.size(); i++) {
				
				if (MailController.lawyers.get(i).getEnabled().equals("√")) {
					mailToday = false;
					writer.append("*************************" + "\n");
					writer.append("Nombre(s): " + LoginController.lawyers.get(i).getName() + "\n");
					writer.append("Apellido(s): " + LoginController.lawyers.get(i).getLastName() + "\n");
					writer.append("Despacho: " + LoginController.lawyers.get(i).getFirm() + "\n");
					writer.append("Correo: " + LoginController.lawyers.get(i).getMail() + "\n");
					writer.append("*************************" + "\n" + "\n");
					String prefs = LoginController.lawyers.get(i).getPrefs();
					System.out.println(prefs);
					String enabledCategories[] =  prefs.split(":");
					for (int j = 0; j < enabledCategories.length; j++) {
						for (int k = 0; k < MailController.articles.size(); k++) {
							if (MailController.articles.get(k).getTitle().contains(enabledCategories[j])) {
								mailToday = true;
								System.out.println(MailController.articles.get(k).getTitle());
								writer.append(MailController.articles.get(k).getTitle() + "\n");
								writer.append(MailController.articles.get(k).getDate() + "\n");
								writer.append(MailController.articles.get(k).getDescription() + "\n");
								writer.append(MailController.articles.get(k).getLink() + "\n");
								writer.append("\n");
							}
						}
					}
					if (mailToday == false) {
						writer.append("No hay noticias nuevas hoy!" + "\n" + "\n");
					}
				}
			}
			
			
			writer.flush();
			writer.close();
			br.close();
		} catch (Exception e) {
			
		}
		
		
		
	}
	
	public static void sendMail() {
		boolean mailToday = false;
		
		final String username = "lawyernews.avm@gmail.com";
		final String password = "ydqexjkllgdcxvcx";
		
		Properties props = new Properties();
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		
		Session session = Session.getInstance(props, 
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		}
				);
		
		for (int i = 0; i < LoginController.lawyers.size(); i++) {
			
			StringBuilder stringBuilder = new StringBuilder();
			
			stringBuilder.append("Hola Lic. " + LoginController.lawyers.get(i).getName() + " " + LoginController.lawyers.get(i).getLastName() + 
					" del despacho " + LoginController.lawyers.get(i).getFirm() + ", aquí está su resumen personalizado del DOF: \n \n");
			
			
			if (MailController.lawyers.get(i).getEnabled().equals("√")) {
				mailToday = false;
				
				String prefs = LoginController.lawyers.get(i).getPrefs();
				System.out.println(prefs);
				String enabledCategories[] =  prefs.split(":");
				for (int j = 0; j < enabledCategories.length; j++) {
					for (int k = 0; k < MailController.articles.size(); k++) {
						if (MailController.articles.get(k).getTitle().contains(enabledCategories[j])) {
							mailToday = true;
							System.out.println(MailController.articles.get(k).getTitle());
							stringBuilder.append(MailController.articles.get(k).getTitle() + "\n");
							stringBuilder.append(MailController.articles.get(k).getDate() + "\n");
							stringBuilder.append(MailController.articles.get(k).getDescription() + "\n");
							stringBuilder.append(MailController.articles.get(k).getLink() + "\n");
							stringBuilder.append("\n");
						}
					}
				}
				if (mailToday == false) {
					stringBuilder.append("¡No hay noticias nuevas hoy!" + "\n" + "\n");
				}
				
				
				try {
					Message mail = new MimeMessage(session);
					mail.setFrom(new InternetAddress(username));
					mail.setRecipients(Message.RecipientType.TO,
							InternetAddress.parse(LoginController.lawyers.get(i).getMail()));
					mail.setSubject("LawyerNews");
					
					mail.setText(stringBuilder.toString());
					Transport.send(mail);
					System.out.println("mail sent");
				} catch (MessagingException e) {
					throw new RuntimeException(e);
				}
			}
		}
		
	}

}
