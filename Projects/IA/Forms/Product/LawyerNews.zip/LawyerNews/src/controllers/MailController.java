package controllers;

import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class MailController implements Initializable {
	
	@FXML private Label titleLabel;
	@FXML private Label errorLabel;
	
	@FXML private TableView<Categories> lawyerTable;
	@FXML private TableColumn<Categories, String> lawyerCol;
	@FXML private TableColumn<Categories, String> statusCol;
	
	@FXML private Button closeButton;
	@FXML private Button enableButton;
	@FXML private Button disableButton;
	@FXML private Button enableAllButton;
	@FXML private Button disableAllButton;
	@FXML private Button sendButton;
	
	@FXML private TextArea consoleText;
	
	@FXML private CheckBox textCheck;
	
	public static ArrayList<Article> articles = new ArrayList<Article>();
	
	public static ArrayList<Categories> lawyers = new ArrayList<Categories>();
	
	@FXML private ObservableList<Categories> data = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		for (int i = 0; i < LoginController.lawyers.size(); i++) {
			Categories lawyer = new Categories();
			lawyer.setCategory(LoginController.lawyers.get(i).getName());
			lawyer.setEnabled("√");
			lawyers.add(lawyer);
			updateTable();
		}
		
		
	}
	
	public void closePressed (ActionEvent event) {
		Stage stage = (Stage) closeButton.getScene().getWindow();
		stage.close();
	}
	
	public void enablePressed (ActionEvent event) {
		Categories selectedLawyer = lawyerTable.getSelectionModel().getSelectedItem();

		for (int i = 0; i < lawyers.size(); i++) {
			if (selectedLawyer.equals(lawyers.get(i))) {
				lawyers.get(i).setEnabled("√");
			}
		}
		updateTable();
	}
	
	public void disablePressed (ActionEvent event) {
		Categories selectedLawyer = lawyerTable.getSelectionModel().getSelectedItem();

		for (int i = 0; i < lawyers.size(); i++) {
			if (selectedLawyer.equals(lawyers.get(i))) {
				lawyers.get(i).setEnabled("X");
			}
		}
		updateTable();
	}
	
	public void enableAllPressed (ActionEvent event) {
		for (int i = 0; i < lawyers.size(); i++) {
			lawyers.get(i).setEnabled("√");
		}
		updateTable();
	}
	
	public void disableAllPressed (ActionEvent event) {
		for (int i = 0; i < lawyers.size(); i++) {
			lawyers.get(i).setEnabled("X");
		}
		updateTable();
	}
	
	public void sendPressed (ActionEvent event) throws UnknownHostException {
		boolean success = true;
		try {
			consoleText.setText("Descargando DOF...");
			XMLTools.downloadXML();
		}
		catch (UnknownHostException e) {
			success = false;
			consoleText.setText(consoleText.getText() + "\n" + "Error al descargar DOF, verifique su conexión a internet y vuelva a intentar.");
		}
		if (success) {
			try {
				consoleText.setText(consoleText.getText() + "\n" + "Acomodando artículos...");
				articles = XMLTools.XMLToArticle();
			}
			catch (Exception e) {
				success = false;
				consoleText.setText(consoleText.getText() + "\n" + "Error al acomodar artículos, por favor vuelva a intentar.");
			}
		}
		if (success) {
			consoleText.setText(consoleText.getText() + "\n" + "Enviando correos...");
			MailTool.sendMail();
			consoleText.setText(consoleText.getText() + "\n" + "Correos enviados exitosamente.");
		}
		if (success && textCheck.isSelected()) {
			MailTool.exportToTXT();
			consoleText.setText(consoleText.getText() + "\n" + "Exportado a TXT exitosamente.");
		}
		
	}
	
	public void updateTable () {
		lawyerTable.getItems().clear();
		
		lawyerCol.setCellValueFactory(new PropertyValueFactory<Categories, String>("category"));
		statusCol.setCellValueFactory(new PropertyValueFactory<Categories, String>("enabled"));
		
		for (int i = 0; i < lawyers.size(); i++) {
			data.add(lawyers.get(i));
		}
		lawyerTable.setItems(data);
		
	}

}
