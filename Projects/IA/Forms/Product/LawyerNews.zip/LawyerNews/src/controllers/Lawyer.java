package controllers;

public class Lawyer {
	
	private String name;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the firm
	 */
	public String getFirm() {
		return firm;
	}
	/**
	 * @param firm the firm to set
	 */
	public void setFirm(String firm) {
		this.firm = firm;
	}
	/**
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}
	/**
	 * @param mail the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}
	/**
	 * @return the prefs
	 */
	public String getPrefs() {
		return prefs;
	}
	/**
	 * @param prefs the prefs to set
	 */
	public void setPrefs(String prefs) {
		this.prefs = prefs;
	}
	private String lastName;
	private String firm;
	private String mail;
	private String prefs;
	

}
