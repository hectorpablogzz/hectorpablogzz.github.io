package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class InfoController implements Initializable {
	
	@FXML private TextField nameField;
	@FXML private TextField lastField;
	@FXML private TextField firmField;
	@FXML private TextField mailField;
	@FXML private Button saveButton;
	@FXML private Label errorLabel;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		nameField.setText(PersonListController.selectedLawyer.getName());
		lastField.setText(PersonListController.selectedLawyer.getLastName());
		firmField.setText(PersonListController.selectedLawyer.getFirm());
		mailField.setText(PersonListController.selectedLawyer.getMail());
		
	}
	
	@FXML
	public void savePressed (ActionEvent event) {
		if (nameField.getText().equals("") || lastField.getText().equals("") || firmField.getText().equals("") || mailField.getText().equals("")) {
			errorLabel.setText("Favor de llenar todas las casillas.");
			
		}
		else  {
			boolean exists = false;
			
			for (int i = 0; i < LoginController.lawyers.size() && exists == false; i++) {
				if (PersonListController.selectedLawyer.equals(LoginController.lawyers.get(i))) {
					LoginController.lawyers.get(i).setName(nameField.getText());
					LoginController.lawyers.get(i).setLastName(lastField.getText());
					LoginController.lawyers.get(i).setFirm(firmField.getText());
					LoginController.lawyers.get(i).setMail(mailField.getText());
					exists = true;
					
				}
			}
			if (exists == false) {
				Lawyer newLawyer = new Lawyer();
				newLawyer.setName(nameField.getText());
				newLawyer.setLastName(lastField.getText());
				newLawyer.setFirm(firmField.getText());
				newLawyer.setMail(mailField.getText());
				newLawyer.setPrefs("PODER LEGISLATIVO");
				LoginController.lawyers.add(newLawyer);
				PersonListController.selectedLawyer = newLawyer;
			}
			
			
			
			Parent rootPersonProfile = null;
			try {
				rootPersonProfile = FXMLLoader.load(getClass().getResource("/application/PersonProfileGUI.fxml"));
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			Scene scenePersonProfile = new Scene(rootPersonProfile);
			PersonListController.personProfile.setScene(scenePersonProfile);
			PersonListController.personProfile.show();
		}
	}
	

}
